package issue42134

func _() {
	/*
	tests contains test cases
	*/
	tests := []struct { //@rename("tests", "testCases")
		in, out string
	}{}
	_ = tests
}
