// Package a is a package for testing go to definition.
package a

import "fmt"

func TypeStuff() { //@Stuff
	var x string

	switch y := interface{}(x).(type) { //@mark(switchY, "y"),godef("y", switchY)
	case int: //@mark(intY, "int")
		fmt.Printf("%v", y) //@hoverdef("y", intY)
	case string: //@mark(stringY, "string")
		fmt.Printf("%v", y) //@hoverdef("y", stringY)
	}

}
