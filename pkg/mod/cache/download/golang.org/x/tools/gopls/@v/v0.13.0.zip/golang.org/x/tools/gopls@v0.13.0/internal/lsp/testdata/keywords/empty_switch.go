package keywords

func _() {
	switch {
		//@complete("", case, default)
	}

	switch test.(type) {
		d //@complete(" //", default)
	}
}
